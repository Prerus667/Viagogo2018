package Model;
import java.util.Random;
public class IdGeneration {
	

	    private int id;

	    private int setId(int newId){
	        return this.id = newId;
	    }

	    
	    public int getId() {
	        Random random = new Random();
	        int randomId = random.nextInt(100);

	        IdGeneration eventId = new IdGeneration();
	        return this.id = eventId.setId(randomId);
	    }

	}



