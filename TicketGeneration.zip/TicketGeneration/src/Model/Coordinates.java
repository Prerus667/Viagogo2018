package Model;

import java.util.Random;

public class Coordinates{
    private double x;
    private double y;

    //Constructor with no parameters.
    public Coordinates(){}

    // Constructor for initial parameters.
    public Coordinates(double x, double y){
        this.x = x;
        this.y = y;
    }

    public double getX(){
        return this.x;
    }
    public double getY(){
        return this.y;
    }

    private double setX(double newX) {
        return this.x=newX;
    }

    private double setY(double newY) {
        return this.y=newY;
    }
   
    public double distanceTo(Coordinates eventPoint) {
        double dx = Math.abs(x - eventPoint.x);
        double dy = Math.abs(y - eventPoint.y);
        return dx + dy;
    }

    public void randomX() {
            Random r = new Random();
            double x = r.nextInt(10 + 1 + 10) - 10;

            Coordinates randPoint = new Coordinates();
            this.x=randPoint.setX(x);
    }

    
    public void randomY() {
        Random r = new Random();
        double y = r.nextInt((10 + 1 + 10) - 10);

        Coordinates randPoint = new Coordinates();
        this.y = randPoint.setY(y);
    }

}
