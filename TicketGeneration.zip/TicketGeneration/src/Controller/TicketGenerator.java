package Controller;

import java.io.IOException
;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.IdGeneration;
import Model.Coordinates;
import Model.TicketPrice;

/**
 * Servlet implementation class TicketGenerator
 */
@WebServlet("/TicketGenerator")
public class TicketGenerator extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public TicketGenerator() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @return 
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		boolean flag;
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		// checking the redirection
		//out.print("Application Working Fine!!!");
		int x=Integer.parseInt(request.getParameter("x"));
		int y=Integer.parseInt(request.getParameter("y"));
		
		
     
        if (x > 10 || y > 10 || x < -10 || y < -10) {
            flag = false;
            out.println("The coordinate ranges are from -10 to +10 , please enter a valid coordinates");
            
        } else {
            flag = true;
           

       
            double[][] items = new double[10][4];

            for (int i = 0 ; i < 10; i++) {

                items[i][0] = i;

               
                IdGeneration Event = new IdGeneration();
                int eventDetails = Event.getId();
                items[i][1] = eventDetails;

                TicketPrice ticketPrice = new TicketPrice();
                ticketPrice.price();
                double price = ticketPrice.getPrice();
                items[i][2] = price;

                Coordinates userCoord = new Coordinates(x, y);
                Coordinates eventCoord = new Coordinates();
                eventCoord.randomX();
                eventCoord.randomY();
                out.print("<style>body{background-image:url('http://www.planwallpaper.com/static/images/cute-wallpapers-17.jpg');}</style>");
                out.print("<html><body>");
                out.println("");
                out.println("<h4><table><tr>"+"<td>Event: " + items[i][0] +"\t Event Location: X Coordinate "
                        + eventCoord.getX() + " Y Coordinate" + eventCoord.getY()+"</td></h4><br></tr>");
                double distance = userCoord.distanceTo(eventCoord);
                items[i][3] = distance;
            }
              out.print("</table>");
            Arrays.sort(items, (o1, o2) -> (int) (o1[3] - o2[3]));
             
         
            out.println("Displaying the events close to you!!!");
            out.println("");

           
            for (int i = 0 ; i < 5 ; i++) {
                out.println("<h4>"+"Event: " + items[i][0] + "\t\tTickets: " + items[i][1] +
                        "\t\tPrice: $" + items[i][2] + "\t\tDistance: " + items[i][3]+"<h4><br>");
            
                out.print("<html><body>");
        }
	
    } 
	}

		                    
	

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
